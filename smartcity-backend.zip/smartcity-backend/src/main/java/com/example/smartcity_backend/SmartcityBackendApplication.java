package com.example.smartcity_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartcityBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartcityBackendApplication.class, args);
	}

}
