package com.example.smartcity_backend.controllers;

import com.example.smartcity_backend.service.UserService;
import com.example.smartcity_backend.dto.LoginRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class AuthController {

    private final UserService userService;

    @Autowired
    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        // Validate user credentials
        boolean isValidUser = userService.validateUser(loginRequest.getEmail(), loginRequest.getPassword());

        if (isValidUser) {
            // In a real-world app, return a JWT or a session cookie instead
            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }
}
