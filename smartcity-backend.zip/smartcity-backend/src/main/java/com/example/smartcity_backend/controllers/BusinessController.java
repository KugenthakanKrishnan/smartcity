package com.example.smartcity_backend.controllers;

import com.example.smartcity_backend.models.Business;
import com.example.smartcity_backend.service.FileStorageService;
import com.example.smartcity_backend.service.BusinessService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.UrlResource;

import java.net.MalformedURLException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/business")
public class BusinessController {

    private final BusinessService businessService;
    private final FileStorageService fileStorageService;

    @Autowired
    public BusinessController(BusinessService businessService, FileStorageService fileStorageService) {
        this.businessService = businessService;
        this.fileStorageService = fileStorageService;
    }

    // New endpoint to get the count of businesses
    @GetMapping("/count")
    public ResponseEntity<Map<String, Integer>> getBusinessCount() {
        int count = businessService.getBusinessCount(); // Call to service method that calculates the count
        Map<String, Integer> response = new HashMap<>();
        response.put("count", count);
        return ResponseEntity.ok(response);
    }

    // Existing endpoint to get a business by ID
    @GetMapping("/{id}")
    public ResponseEntity<Business> getBusinessById(@PathVariable Long id) {
        Optional<Business> business = businessService.getBusinessById(id);
        return business.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping(consumes = {"multipart/form-data"})
    public ResponseEntity<Business> addBusiness(
            @RequestParam("name") String name,
            @RequestParam("category") String category,
            @RequestParam("address") String address,
            @RequestParam(value = "contactInfo", required = false) String contactInfo,
            @RequestParam(value = "description", required = false) String description,
            @RequestParam(value = "website", required = false) String website,
            @RequestParam(value = "latitude", required = false) Double latitude,
            @RequestParam(value = "longitude", required = false) Double longitude,
            @RequestParam(value = "image", required = false) MultipartFile image) {

        String imageName = null;
        if (image != null && !image.isEmpty()) {
            imageName = fileStorageService.storeFile(image);
        }

        Business business = new Business();
        business.setName(name);
        business.setCategory(Business.Category.valueOf(category.toUpperCase().replace(" ", "_")));
        business.setAddress(address);
        business.setContactInfo(contactInfo);
        business.setDescription(description);
        business.setWebsite(website);
        business.setLatitude(latitude);
        business.setLongitude(longitude);
        business.setImage(imageName);

        Business newBusiness = businessService.addBusiness(business);
        return ResponseEntity.ok(newBusiness);
    }

    @PutMapping(value = "/{id}", consumes = {"multipart/form-data"})
    public ResponseEntity<Business> updateBusiness(
            @PathVariable Long id,
            @RequestParam("name") String name,
            @RequestParam("category") String category,
            @RequestParam("address") String address,
            @RequestParam(value = "contactInfo", required = false) String contactInfo,
            @RequestParam(value = "description", required = false) String description,
            @RequestParam(value = "website", required = false) String website,
            @RequestParam(value = "latitude", required = false) Double latitude,
            @RequestParam(value = "longitude", required = false) Double longitude,
            @RequestParam(value = "image", required = false) MultipartFile image) {

        Optional<Business> existingBusiness = businessService.getBusinessById(id);
        if (existingBusiness.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Business business = existingBusiness.get();
        business.setName(name);
        business.setCategory(Business.Category.valueOf(category.toUpperCase().replace(" ", "_")));
        business.setAddress(address);
        business.setContactInfo(contactInfo);
        business.setDescription(description);
        business.setWebsite(website);
        business.setLatitude(latitude);
        business.setLongitude(longitude);

        if (image != null && !image.isEmpty()) {
            String imageName = fileStorageService.storeFile(image);
            business.setImage(imageName);
        }

        Business updatedBusiness = businessService.updateBusiness(id, business);
        return ResponseEntity.ok(updatedBusiness);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBusiness(@PathVariable Long id) {
        Optional<Business> existingBusiness = businessService.getBusinessById(id);
        if (existingBusiness.isPresent()) {
            businessService.deleteBusiness(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public ResponseEntity<List<Business>> getAllBusinesses() {
        List<Business> businessList = businessService.getAllBusinesses();
        return ResponseEntity.ok(businessList);
    }

    @GetMapping("/first")
    public ResponseEntity<Business> getFirstBusiness() {
        Optional<Business> firstBusiness = businessService.getAllBusinesses().stream().findFirst();
        return firstBusiness.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/images/{filename}")
    @ResponseBody
    public ResponseEntity<Resource> getImage(@PathVariable String filename) {
        try {
            Path filePath = fileStorageService.getFileLocation(filename);
            Resource resource = new UrlResource(filePath.toUri());
            return ResponseEntity.ok()
                    .contentType(MediaType.IMAGE_JPEG)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                    .body(resource);
        } catch (MalformedURLException ex) {
            return ResponseEntity.notFound().build();
        }
    }
}
