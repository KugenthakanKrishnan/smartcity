package com.example.smartcity_backend.controllers;

import com.example.smartcity_backend.models.EmergencyContact;
import com.example.smartcity_backend.service.EmergencyContactService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/emergency_contacts")
public class EmergencyContactController {

    private final EmergencyContactService emergencyContactService;

    @Autowired
    public EmergencyContactController(EmergencyContactService emergencyContactService) {
        this.emergencyContactService = emergencyContactService;
    }

    @PostMapping
    public ResponseEntity<EmergencyContact> addEmergencyContact(
            @RequestParam("type") String type,
            @RequestParam("phoneNumber") String phoneNumber,
            @RequestParam(value = "description", required = false) String description,
            @RequestParam(value = "latitude", required = false) Double latitude,
            @RequestParam(value = "longitude", required = false) Double longitude) {

        EmergencyContact emergencyContact = new EmergencyContact();
        emergencyContact.setType(EmergencyContact.ContactType.valueOf(type.toUpperCase().replace(" ", "_")));
        emergencyContact.setPhoneNumber(phoneNumber);
        emergencyContact.setDescription(description);
        emergencyContact.setLatitude(latitude);
        emergencyContact.setLongitude(longitude);

        EmergencyContact newContact = emergencyContactService.addEmergencyContact(emergencyContact);
        return ResponseEntity.ok(newContact);
    }

    @GetMapping
    public ResponseEntity<List<EmergencyContact>> getAllEmergencyContacts() {
        List<EmergencyContact> contactsList = emergencyContactService.getAllEmergencyContacts();
        return ResponseEntity.ok(contactsList);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EmergencyContact> updateEmergencyContact(
            @PathVariable Long id,
            @RequestParam("type") String type,
            @RequestParam("phoneNumber") String phoneNumber,
            @RequestParam(value = "description", required = false) String description,
            @RequestParam(value = "latitude", required = false) Double latitude,
            @RequestParam(value = "longitude", required = false) Double longitude) {

        Optional<EmergencyContact> existingContactOpt = emergencyContactService.getEmergencyContactById(id);
        if (existingContactOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        EmergencyContact emergencyContact = existingContactOpt.get();
        emergencyContact.setType(EmergencyContact.ContactType.valueOf(type.toUpperCase().replace(" ", "_")));
        emergencyContact.setPhoneNumber(phoneNumber);
        emergencyContact.setDescription(description);
        emergencyContact.setLatitude(latitude);
        emergencyContact.setLongitude(longitude);

        EmergencyContact updatedContact = emergencyContactService.updateEmergencyContact(id, emergencyContact);
        return ResponseEntity.ok(updatedContact);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmergencyContact(@PathVariable Long id) {
        Optional<EmergencyContact> existingContactOpt = emergencyContactService.getEmergencyContactById(id);
        if (existingContactOpt.isPresent()) {
            emergencyContactService.deleteEmergencyContact(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
