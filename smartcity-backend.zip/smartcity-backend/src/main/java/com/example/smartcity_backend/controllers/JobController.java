package com.example.smartcity_backend.controllers;

import com.example.smartcity_backend.models.Job;
import com.example.smartcity_backend.service.FileStorageService;
import com.example.smartcity_backend.service.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.UrlResource;

import java.net.MalformedURLException;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/jobs")
public class JobController {

    private final JobService jobService;
    private final FileStorageService fileStorageService;

    @Autowired
    public JobController(JobService jobService, FileStorageService fileStorageService) {
        this.jobService = jobService;
        this.fileStorageService = fileStorageService;
    }

    // New endpoint to get the count of jobs
    @GetMapping("/count")
    public ResponseEntity<Map<String, Integer>> getJobCount() {
        int count = jobService.getJobCount(); // Call to service method that calculates the count
        Map<String, Integer> response = new HashMap<>();
        response.put("count", count);
        return ResponseEntity.ok(response);
    }

    // Existing endpoint to get a job by ID
    @GetMapping("/{id}")
    public ResponseEntity<Job> getJobById(@PathVariable Long id) {
        Optional<Job> job = jobService.getJobById(id);
        return job.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping(consumes = {"multipart/form-data"})
    public ResponseEntity<Job> addJob(
            @RequestParam("title") String title,
            @RequestParam("companyName") String companyName,
            @RequestParam("industry") String industry,
            @RequestParam(value = "address", required = false) String address,
            @RequestParam(value = "latitude", required = false) Double latitude,
            @RequestParam(value = "longitude", required = false) Double longitude,
            @RequestParam(value = "description", required = false) String description,
            @RequestParam(value = "salaryRange", required = false) String salaryRange,
            @RequestParam(value = "postingDate", required = false) String postingDate,
            @RequestParam(value = "contactEmail", required = false) String contactEmail,
            @RequestParam(value = "image", required = false) MultipartFile image) {

        String imageName = null;
        if (image != null && !image.isEmpty()) {
            imageName = fileStorageService.storeFile(image);
        }

        Job job = new Job();
        job.setTitle(title);
        job.setCompanyName(companyName);
        job.setIndustry(Job.Industry.valueOf(industry.toUpperCase().replace(" ", "_")));
        job.setAddress(address);
        job.setLatitude(latitude);
        job.setLongitude(longitude);
        job.setDescription(description);
        job.setSalaryRange(salaryRange);
        job.setPostingDate(postingDate != null ? LocalDate.parse(postingDate) : LocalDate.now());
        job.setContactEmail(contactEmail);
        job.setImage(imageName);

        Job newJob = jobService.addJob(job);
        return ResponseEntity.ok(newJob);
    }

    @PutMapping(value = "/{id}", consumes = {"multipart/form-data"})
    public ResponseEntity<Job> updateJob(
            @PathVariable Long id,
            @RequestParam("title") String title,
            @RequestParam("companyName") String companyName,
            @RequestParam("industry") String industry,
            @RequestParam(value = "address", required = false) String address,
            @RequestParam(value = "latitude", required = false) Double latitude,
            @RequestParam(value = "longitude", required = false) Double longitude,
            @RequestParam(value = "description", required = false) String description,
            @RequestParam(value = "salaryRange", required = false) String salaryRange,
            @RequestParam(value = "postingDate", required = false) String postingDate,
            @RequestParam(value = "contactEmail", required = false) String contactEmail,
            @RequestParam(value = "image", required = false) MultipartFile image) {

        Optional<Job> existingJob = jobService.getJobById(id);
        if (existingJob.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Job job = existingJob.get();
        job.setTitle(title);
        job.setCompanyName(companyName);
        job.setIndustry(Job.Industry.valueOf(industry.toUpperCase().replace(" ", "_")));
        job.setAddress(address);
        job.setLatitude(latitude);
        job.setLongitude(longitude);
        job.setDescription(description);
        job.setSalaryRange(salaryRange);
        job.setPostingDate(postingDate != null ? LocalDate.parse(postingDate) : LocalDate.now());
        job.setContactEmail(contactEmail);

        if (image != null && !image.isEmpty()) {
            String imageName = fileStorageService.storeFile(image);
            job.setImage(imageName);
        }

        Job updatedJob = jobService.updateJob(id, job);
        return ResponseEntity.ok(updatedJob);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteJob(@PathVariable Long id) {
        Optional<Job> existingJob = jobService.getJobById(id);
        if (existingJob.isPresent()) {
            jobService.deleteJob(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public ResponseEntity<List<Job>> getAllJobs() {
        List<Job> jobList = jobService.getAllJobs();
        return ResponseEntity.ok(jobList);
    }

    @GetMapping("/first")
    public ResponseEntity<Job> getFirstJob() {
        Optional<Job> firstJob = jobService.getAllJobs().stream().findFirst();
        return firstJob.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/images/{filename}")
    @ResponseBody
    public ResponseEntity<Resource> getImage(@PathVariable String filename) {
        try {
            Path filePath = fileStorageService.getFileLocation(filename);
            Resource resource = new UrlResource(filePath.toUri());
            return ResponseEntity.ok()
                    .contentType(MediaType.IMAGE_JPEG)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                    .body(resource);
        } catch (MalformedURLException ex) {
            return ResponseEntity.notFound().build();
        }
    }
}
