package com.example.smartcity_backend.controllers;

import com.example.smartcity_backend.models.StudentModule;
import com.example.smartcity_backend.service.FileStorageService;
import com.example.smartcity_backend.service.StudentModuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.UrlResource;

import java.net.MalformedURLException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/student_module")
public class StudentModuleController {

    private final StudentModuleService studentModuleService;
    private final FileStorageService fileStorageService;

    @Autowired
    public StudentModuleController(StudentModuleService studentModuleService, FileStorageService fileStorageService) {
        this.studentModuleService = studentModuleService;
        this.fileStorageService = fileStorageService;
    }

    // New endpoint to get the count of student modules
    @GetMapping("/count")
    public ResponseEntity<Map<String, Integer>> getStudentModuleCount() {
        int count = studentModuleService.getStudentModuleCount(); // Call to service method that calculates the count
        Map<String, Integer> response = new HashMap<>();
        response.put("count", count);
        return ResponseEntity.ok(response);
    }

    // New endpoint to get a student module by ID
    @GetMapping("/{id}")
    public ResponseEntity<StudentModule> getStudentModuleById(@PathVariable Long id) {
        Optional<StudentModule> studentModule = studentModuleService.getStudentModuleById(id);
        return studentModule.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping(consumes = {"multipart/form-data"})
    public ResponseEntity<StudentModule> addStudentModule(
            @RequestParam("name") String name,
            @RequestParam("type") String type,
            @RequestParam("address") String address,
            @RequestParam(value = "contact", required = false) String contact,
            @RequestParam(value = "description", required = false) String description,
            @RequestParam(value = "latitude", required = false) Double latitude,
            @RequestParam(value = "longitude", required = false) Double longitude,
            @RequestParam(value = "image", required = false) MultipartFile image) {

        String imageName = null;
        if (image != null && !image.isEmpty()) {
            imageName = fileStorageService.storeFile(image);
        }

        StudentModule studentModule = new StudentModule();
        studentModule.setName(name);
        studentModule.setType(StudentModule.ModuleType.valueOf(type.toUpperCase().replace(" ", "_")));
        studentModule.setAddress(address);
        studentModule.setContact(contact);
        studentModule.setDescription(description);
        studentModule.setLatitude(latitude);
        studentModule.setLongitude(longitude);
        studentModule.setImage(imageName);

        StudentModule newStudentModule = studentModuleService.addStudentModule(studentModule);
        return ResponseEntity.ok(newStudentModule);
    }

    @PutMapping(value = "/{id}", consumes = {"multipart/form-data"})
    public ResponseEntity<StudentModule> updateStudentModule(
            @PathVariable Long id,
            @RequestParam("name") String name,
            @RequestParam("type") String type,
            @RequestParam("address") String address,
            @RequestParam(value = "contact", required = false) String contact,
            @RequestParam(value = "description", required = false) String description,
            @RequestParam(value = "latitude", required = false) Double latitude,
            @RequestParam(value = "longitude", required = false) Double longitude,
            @RequestParam(value = "image", required = false) MultipartFile image) {

        Optional<StudentModule> existingModuleOpt = studentModuleService.getStudentModuleById(id);
        if (existingModuleOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        StudentModule studentModule = existingModuleOpt.get();
        studentModule.setName(name);
        studentModule.setType(StudentModule.ModuleType.valueOf(type.toUpperCase().replace(" ", "_")));
        studentModule.setAddress(address);
        studentModule.setContact(contact);
        studentModule.setDescription(description);
        studentModule.setLatitude(latitude);
        studentModule.setLongitude(longitude);

        if (image != null && !image.isEmpty()) {
            String imageName = fileStorageService.storeFile(image);
            studentModule.setImage(imageName);
        }

        StudentModule updatedModule = studentModuleService.updateStudentModule(id, studentModule);
        return ResponseEntity.ok(updatedModule);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudentModule(@PathVariable Long id) {
        Optional<StudentModule> existingModule = studentModuleService.getStudentModuleById(id);
        if (existingModule.isPresent()) {
            studentModuleService.deleteStudentModule(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public ResponseEntity<List<StudentModule>> getAllStudentModules() {
        List<StudentModule> studentModuleList = studentModuleService.getAllStudentModules();
        return ResponseEntity.ok(studentModuleList);
    }

    @GetMapping("/first")
    public ResponseEntity<StudentModule> getFirstStudentModule() {
        Optional<StudentModule> firstModule = studentModuleService.getAllStudentModules().stream().findFirst();
        return firstModule.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/images/{filename}")
    @ResponseBody
    public ResponseEntity<Resource> getImage(@PathVariable String filename) {
        try {
            Path filePath = fileStorageService.getFileLocation(filename);
            Resource resource = new UrlResource(filePath.toUri());
            return ResponseEntity.ok()
                    .contentType(MediaType.IMAGE_JPEG)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                    .body(resource);
        } catch (MalformedURLException ex) {
            return ResponseEntity.notFound().build();
        }
    }
}
