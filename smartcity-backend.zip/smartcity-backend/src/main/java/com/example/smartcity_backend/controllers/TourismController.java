package com.example.smartcity_backend.controllers;

import com.example.smartcity_backend.models.Tourism;
import com.example.smartcity_backend.service.FileStorageService;
import com.example.smartcity_backend.service.TourismService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.UrlResource;

import java.net.MalformedURLException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/tourism")
public class TourismController {

    private final TourismService tourismService;
    private final FileStorageService fileStorageService;

    @Autowired
    public TourismController(TourismService tourismService, FileStorageService fileStorageService) {
        this.tourismService = tourismService;
        this.fileStorageService = fileStorageService;
    }

    // New endpoint to get the count of tourism entries
    @GetMapping("/count")
    public ResponseEntity<Map<String, Integer>> getTourismCount() {
        int count = tourismService.getTourismCount(); // Call to service method that calculates the count
        Map<String, Integer> response = new HashMap<>();
        response.put("count", count);
        return ResponseEntity.ok(response);
    }

    // New endpoint to get a tourism entry by ID
    @GetMapping("/{id}")
    public ResponseEntity<Tourism> getTourismById(@PathVariable Long id) {
        Optional<Tourism> tourism = tourismService.getTourismById(id);
        return tourism.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping(consumes = {"multipart/form-data"})
    public ResponseEntity<Tourism> addTourism(
            @RequestParam("name") String name,
            @RequestParam("type") String type,
            @RequestParam("address") String address,
            @RequestParam(value = "phone", required = false) String phone,
            @RequestParam(value = "description", required = false) String description,
            @RequestParam(value = "latitude", required = false) Double latitude,
            @RequestParam(value = "longitude", required = false) Double longitude,
            @RequestParam(value = "image", required = false) MultipartFile image) {

        String imageName = null;
        if (image != null && !image.isEmpty()) {
            imageName = fileStorageService.storeFile(image);
        }

        Tourism tourism = new Tourism();
        tourism.setName(name);
        tourism.setType(Tourism.TourismType.valueOf(type.toUpperCase()));
        tourism.setAddress(address);
        tourism.setPhone(phone);
        tourism.setDescription(description);
        tourism.setLatitude(latitude);
        tourism.setLongitude(longitude);
        tourism.setImage(imageName);

        Tourism newTourism = tourismService.addTourism(tourism);
        return ResponseEntity.ok(newTourism);
    }

    @PutMapping(value = "/{id}", consumes = {"multipart/form-data"})
    public ResponseEntity<Tourism> updateTourism(
            @PathVariable Long id,
            @RequestParam("name") String name,
            @RequestParam("type") String type,
            @RequestParam("address") String address,
            @RequestParam(value = "phone", required = false) String phone,
            @RequestParam(value = "description", required = false) String description,
            @RequestParam(value = "latitude", required = false) Double latitude,
            @RequestParam(value = "longitude", required = false) Double longitude,
            @RequestParam(value = "image", required = false) MultipartFile image) {

        Optional<Tourism> existingTourism = tourismService.getTourismById(id);
        if (existingTourism.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Tourism tourism = existingTourism.get();
        tourism.setName(name);
        tourism.setType(Tourism.TourismType.valueOf(type.toUpperCase()));
        tourism.setAddress(address);
        tourism.setPhone(phone);
        tourism.setDescription(description);
        tourism.setLatitude(latitude);
        tourism.setLongitude(longitude);

        if (image != null && !image.isEmpty()) {
            String imageName = fileStorageService.storeFile(image);
            tourism.setImage(imageName);
        }

        Tourism updatedTourism = tourismService.updateTourism(id, tourism);
        return ResponseEntity.ok(updatedTourism);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTourism(@PathVariable Long id) {
        Optional<Tourism> existingTourism = tourismService.getTourismById(id);
        if (existingTourism.isPresent()) {
            tourismService.deleteTourism(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public ResponseEntity<List<Tourism>> getAllTourism() {
        List<Tourism> tourismList = tourismService.getAllTourism();
        return ResponseEntity.ok(tourismList);
    }

    @GetMapping("/first")
    public ResponseEntity<Tourism> getFirstTourism() {
        Optional<Tourism> firstTourism = tourismService.getAllTourism().stream().findFirst();
        return firstTourism.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/images/{filename}")
    @ResponseBody
    public ResponseEntity<Resource> getImage(@PathVariable String filename) {
        try {
            Path filePath = fileStorageService.getFileLocation(filename);
            Resource resource = new UrlResource(filePath.toUri());
            return ResponseEntity.ok()
                    .contentType(MediaType.IMAGE_JPEG)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                    .body(resource);
        } catch (MalformedURLException ex) {
            return ResponseEntity.notFound().build();
        }
    }
}
