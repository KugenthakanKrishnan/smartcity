package com.example.smartcity_backend.factories;

import com.example.smartcity_backend.models.User;

public class UserFactory {

    // Factory method to create a User with basic information
    public static User createUser(String username, String email, String phone, String password) {
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPhone(phone);
        user.setPassword(password);
        return user;
    }
}
