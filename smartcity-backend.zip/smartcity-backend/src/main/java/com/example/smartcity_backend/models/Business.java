package com.example.smartcity_backend.models;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "business")
public class Business implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long businessId;

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Category category;

    @Column(nullable = false)
    private String address;

    private String contactInfo;
    private String description;
    private String website;
    private String image;
    private Double latitude;
    private Double longitude;

    // Enum for Business Category Types
    public enum Category {
        RESTAURANT,
        CAFE,
        RETAIL,
        SERVICE,
        ENTERTAINMENT,
        HEALTHCARE,
        EDUCATION,
        FINANCE,
        TECHNOLOGY,
        TRAVEL
    }

    public Double getLongitude() {
        return longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public String getImage() {
        return image;
    }

    public String getWebsite() {
        return website;
    }

    public String getDescription() {
        return description;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public String getAddress() {
        return address;
    }

    public Category getCategory() {
        return category;
    }

    public String getName() {
        return name;
    }

    public Long getBusinessId() {
        return businessId;
    }
// Getters and Setters


    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    // Default Constructor
    public Business() {}
}
