package com.example.smartcity_backend.models;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "emergency_contacts")
public class EmergencyContact implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long contactId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ContactType type;

    @Column(nullable = false)
    private String phoneNumber;

    private String description;
    private Double latitude;
    private Double longitude;

    // Enum for Contact Types
    public enum ContactType {
        POLICE,
        AMBULANCE,
        FIRE_DEPARTMENT,
        HOSPITAL,
        RESCUE_TEAM,
        DISASTER_MANAGEMENT,
        OTHER
    }

    // Getters and Setters4


    public Long getContactId() {
        return contactId;
    }

    public void setContactId(Long contactId) {
        this.contactId = contactId;
    }

    public ContactType getType() {
        return type;
    }

    public void setType(ContactType type) {
        this.type = type;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    // Default Constructor
    public EmergencyContact() {}
}
