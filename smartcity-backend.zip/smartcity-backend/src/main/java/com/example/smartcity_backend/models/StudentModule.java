package com.example.smartcity_backend.models;

import jakarta.persistence.*;
import java.io.Serializable;


@Entity
@Table(name = "student_module")
public class StudentModule implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long studentId;

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ModuleType type;

    @Column(nullable = false)
    private String address;

    private String contact;
    private String description;
    private String image;
    private Double latitude;
    private Double longitude;

    public enum ModuleType {
        LIBRARY,
        COACHING_CENTER,
        COLLEGE,
        UNIVERSITY,
        SCHOOL,
        ONLINE_COURSE,
        TRAINING_INSTITUTE
    }

    // Getters and Setters
    // ...

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ModuleType getType() {
        return type;
    }

    public void setType(ModuleType type) {
        this.type = type;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }
}

