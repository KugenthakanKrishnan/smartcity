package com.example.smartcity_backend.models;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "tourism")
public class Tourism implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long tourismId;

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TourismType type;

    @Column(nullable = false)
    private String address;

    private String phone;
    private String description;
    private String image;
    private Double latitude;
    private Double longitude;

    // Default Constructor
    public Tourism() {}

    // Getters and Setters

    public Long getTourismId() {
        return tourismId;
    }

    public void setTourismId(Long tourismId) {
        this.tourismId = tourismId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public TourismType getType() {
        return type;
    }

    public void setType(TourismType type) {
        this.type = type;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    // Enum for tourism type
    public enum TourismType {
        HOTEL,
        RESTAURANT,
        ATTRACTION,
        ATM,
        THEATRE,
        MUSEUM,
        PARK,
        SHOPPINGMALL,
        AIRPORT,
        TRAINSTATION
    }
}
