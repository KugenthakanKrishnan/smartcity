package com.example.smartcity_backend.repositories;

import com.example.smartcity_backend.models.StudentModule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentModuleRepository extends JpaRepository<StudentModule, Long> {
    // Additional custom queries can be added here if needed
}
