package com.example.smartcity_backend.service;

import com.example.smartcity_backend.models.Business;
import com.example.smartcity_backend.repositories.BusinessRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BusinessService {

    private final BusinessRepository businessRepository;

    @Autowired
    public BusinessService(BusinessRepository businessRepository) {
        this.businessRepository = businessRepository;
    }

    // Method to get the count of all businesses
    public int getBusinessCount() {
        return (int) businessRepository.count(); // Counting all businesses in the 'business' table
    }

    // Add a new business
    public Business addBusiness(Business business) {
        return businessRepository.save(business);
    }

    // Retrieve all businesses
    public List<Business> getAllBusinesses() {
        return businessRepository.findAll();
    }

    // Retrieve a business by ID
    public Optional<Business> getBusinessById(Long id) {
        return businessRepository.findById(id);
    }

    // Update an existing business
    public Business updateBusiness(Long id, Business updatedBusiness) {
        return businessRepository.findById(id).map(business -> {
            business.setName(updatedBusiness.getName());
            business.setCategory(updatedBusiness.getCategory());
            business.setAddress(updatedBusiness.getAddress());
            business.setContactInfo(updatedBusiness.getContactInfo());
            business.setDescription(updatedBusiness.getDescription());
            business.setWebsite(updatedBusiness.getWebsite());
            business.setLatitude(updatedBusiness.getLatitude());
            business.setLongitude(updatedBusiness.getLongitude());
            business.setImage(updatedBusiness.getImage());
            return businessRepository.save(business);
        }).orElseThrow(() -> new IllegalArgumentException("Business with ID " + id + " not found"));
    }

    // Delete a business by ID
    public void deleteBusiness(Long id) {
        businessRepository.deleteById(id);
    }
}
