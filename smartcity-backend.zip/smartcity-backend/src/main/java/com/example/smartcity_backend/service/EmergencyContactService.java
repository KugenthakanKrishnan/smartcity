package com.example.smartcity_backend.service;

import com.example.smartcity_backend.models.EmergencyContact;
import com.example.smartcity_backend.repositories.EmergencyContactRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmergencyContactService {

    private final EmergencyContactRepository emergencyContactRepository;

    @Autowired
    public EmergencyContactService(EmergencyContactRepository emergencyContactRepository) {
        this.emergencyContactRepository = emergencyContactRepository;
    }

    public EmergencyContact addEmergencyContact(EmergencyContact emergencyContact) {
        return emergencyContactRepository.save(emergencyContact);
    }

    public List<EmergencyContact> getAllEmergencyContacts() {
        return emergencyContactRepository.findAll();
    }

    public Optional<EmergencyContact> getEmergencyContactById(Long id) {
        return emergencyContactRepository.findById(id);
    }

    public EmergencyContact updateEmergencyContact(Long id, EmergencyContact updatedContact) {
        return emergencyContactRepository.findById(id).map(contact -> {
            contact.setType(updatedContact.getType());
            contact.setPhoneNumber(updatedContact.getPhoneNumber());
            contact.setDescription(updatedContact.getDescription());
            contact.setLatitude(updatedContact.getLatitude());
            contact.setLongitude(updatedContact.getLongitude());
            return emergencyContactRepository.save(contact);
        }).orElseThrow(() -> new IllegalArgumentException("Emergency contact with ID " + id + " not found"));
    }

    public void deleteEmergencyContact(Long id) {
        emergencyContactRepository.deleteById(id);
    }
}
