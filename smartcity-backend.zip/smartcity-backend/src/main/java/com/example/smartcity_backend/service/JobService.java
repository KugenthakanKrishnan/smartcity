package com.example.smartcity_backend.service;

import com.example.smartcity_backend.models.Job;
import com.example.smartcity_backend.repositories.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class JobService {

    private final JobRepository jobRepository;

    @Autowired
    public JobService(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    // Method to get the count of all jobs
    public int getJobCount() {
        return (int) jobRepository.count(); // Counting all jobs in the 'job' table
    }

    public Job addJob(Job job) {
        return jobRepository.save(job);
    }

    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

    public Optional<Job> getJobById(Long id) {
        return jobRepository.findById(id);
    }

    public Job updateJob(Long id, Job updatedJob) {
        return jobRepository.findById(id).map(job -> {
            job.setTitle(updatedJob.getTitle());
            job.setCompanyName(updatedJob.getCompanyName());
            job.setIndustry(updatedJob.getIndustry());
            job.setAddress(updatedJob.getAddress());
            job.setLatitude(updatedJob.getLatitude());
            job.setLongitude(updatedJob.getLongitude());
            job.setDescription(updatedJob.getDescription());
            job.setSalaryRange(updatedJob.getSalaryRange());
            job.setPostingDate(updatedJob.getPostingDate());
            job.setContactEmail(updatedJob.getContactEmail());
            job.setImage(updatedJob.getImage());
            return jobRepository.save(job);
        }).orElseThrow(() -> new IllegalArgumentException("Job with ID " + id + " not found"));
    }

    public void deleteJob(Long id) {
        jobRepository.deleteById(id);
    }
}
