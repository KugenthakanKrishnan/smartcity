package com.example.smartcity_backend.service;

import com.example.smartcity_backend.models.Reservation;
import com.example.smartcity_backend.repositories.ReservationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ReservationService {

    private final ReservationRepository reservationRepository;

    @Autowired
    public ReservationService(ReservationRepository reservationRepository) {
        this.reservationRepository = reservationRepository;
    }

    // Method to get all reservations
    public List<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }

    // Method to get a reservation by ID
    public Optional<Reservation> getReservationById(Long id) {
        return reservationRepository.findById(id);
    }

    // Method to create a new reservation
    public Reservation createReservation(Reservation reservation) {
        return reservationRepository.save(reservation);
    }

    // Method to update an existing reservation
    public Reservation updateReservation(Long id, Reservation reservation) {
        return reservationRepository.findById(id).map(existingReservation -> {
            existingReservation.setFirstName(reservation.getFirstName());
            existingReservation.setLastName(reservation.getLastName());
            existingReservation.setEmail(reservation.getEmail());
            existingReservation.setPhone(reservation.getPhone());
            existingReservation.setCountry(reservation.getCountry());
            existingReservation.setReservationDate(reservation.getReservationDate());
            existingReservation.setReservationTime(reservation.getReservationTime());
            existingReservation.setNumberOfMembers(reservation.getNumberOfMembers());
            return reservationRepository.save(existingReservation);
        }).orElseThrow(() -> new IllegalArgumentException("Reservation with ID " + id + " not found"));
    }

    // Method to delete a reservation by ID
    public void deleteReservation(Long id) {
        reservationRepository.deleteById(id);
    }
}
