package com.example.smartcity_backend.service;

import com.example.smartcity_backend.models.StudentModule;
import com.example.smartcity_backend.repositories.StudentModuleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentModuleService {

    private final StudentModuleRepository studentModuleRepository;

    @Autowired
    public StudentModuleService(StudentModuleRepository studentModuleRepository) {
        this.studentModuleRepository = studentModuleRepository;
    }

    // Method to get the count of all student modules
    public int getStudentModuleCount() {
        return (int) studentModuleRepository.count(); // Counting all student modules in the 'student_module' table
    }

    public StudentModule addStudentModule(StudentModule studentModule) {
        return studentModuleRepository.save(studentModule);
    }

    public List<StudentModule> getAllStudentModules() {
        return studentModuleRepository.findAll();
    }

    public Optional<StudentModule> getStudentModuleById(Long id) {
        return studentModuleRepository.findById(id);
    }

    public StudentModule updateStudentModule(Long id, StudentModule updatedModule) {
        return studentModuleRepository.findById(id).map(module -> {
            module.setName(updatedModule.getName());
            module.setType(updatedModule.getType());
            module.setAddress(updatedModule.getAddress());
            module.setContact(updatedModule.getContact());
            module.setDescription(updatedModule.getDescription());
            module.setLatitude(updatedModule.getLatitude());
            module.setLongitude(updatedModule.getLongitude());
            module.setImage(updatedModule.getImage());
            return studentModuleRepository.save(module);
        }).orElseThrow(() -> new IllegalArgumentException("StudentModule with ID " + id + " not found"));
    }

    public void deleteStudentModule(Long id) {
        studentModuleRepository.deleteById(id);
    }
}
