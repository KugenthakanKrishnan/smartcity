package com.example.smartcity_backend.service;

import com.example.smartcity_backend.models.Tourism;
import com.example.smartcity_backend.repositories.TourismRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TourismService {

    private final TourismRepository tourismRepository;

    @Autowired
    public TourismService(TourismRepository tourismRepository) {
        this.tourismRepository = tourismRepository;
    }

    // Method to get the count of all tourism entries
    public int getTourismCount() {
        return (int) tourismRepository.count(); // Counting all tourism entries in the 'tourism' table
    }

    public Tourism addTourism(Tourism tourism) {
        return tourismRepository.save(tourism);
    }

    public List<Tourism> getAllTourism() {
        return tourismRepository.findAll();
    }

    public Optional<Tourism> getTourismById(Long id) {
        return tourismRepository.findById(id);
    }

    public Tourism updateTourism(Long id, Tourism updatedTourism) {
        return tourismRepository.findById(id).map(tourism -> {
            tourism.setName(updatedTourism.getName());
            tourism.setType(updatedTourism.getType());
            tourism.setAddress(updatedTourism.getAddress());
            tourism.setPhone(updatedTourism.getPhone());
            tourism.setDescription(updatedTourism.getDescription());
            tourism.setLatitude(updatedTourism.getLatitude());
            tourism.setLongitude(updatedTourism.getLongitude());
            tourism.setImage(updatedTourism.getImage());
            return tourismRepository.save(tourism);
        }).orElseThrow(() -> new IllegalArgumentException("Tourism entry with ID " + id + " not found"));
    }

    public void deleteTourism(Long id) {
        tourismRepository.deleteById(id);
    }
}
