package com.example.smartcity_backend.service;

import com.example.smartcity_backend.models.User;
import com.example.smartcity_backend.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Add a new user
    public User addUser(String username, String email, String phone, String password) {
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPhone(phone);
        user.setPassword(password);
        return userRepository.save(user);
    }

    // Validate user credentials (email and password)
    public boolean validateUser(String email, String password) {
        User user = userRepository.findByEmail(email);  // Assuming email is unique
        return user != null && user.getPassword().equals(password);
    }

    // Retrieve all users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // Retrieve a user by ID
    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    // Update an existing user
    public User updateUser(Long id, String username, String email, String phone, String password) {
        return userRepository.findById(id).map(user -> {
            user.setUsername(username);
            user.setEmail(email);
            user.setPhone(phone);
            user.setPassword(password);
            return userRepository.save(user);
        }).orElseThrow(() -> new IllegalArgumentException("User with ID " + id + " not found"));
    }

    // Delete a user by ID
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    // Get the count of users
    public int getUserCount() {
        return (int) userRepository.count(); // Counting all users in the 'user_table' table
    }
}
