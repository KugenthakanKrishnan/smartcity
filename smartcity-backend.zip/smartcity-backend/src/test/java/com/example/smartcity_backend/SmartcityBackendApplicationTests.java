package com.example.smartcity_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartcityBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
